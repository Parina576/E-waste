import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:gradient_borders/gradient_borders.dart';
import 'sign_up_page.dart';

class ProfilePage extends StatelessWidget {
  final String email;
  final String userName;
  final String? profileImageUrl;

  const ProfilePage({
    super.key, 
    required this.email, 
    this.userName = 'User', 
    this.profileImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1B5E20),  
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildSliverAppBar(context),
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFF388E3C),  
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                  topRight: Radius.circular(35),
                ),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  _buildProfileHeader(),
                  const SizedBox(height: 30),
                  _buildStatsRow(),
                  const SizedBox(height: 30),
                  _buildProfileActions(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  SliverAppBar _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 250,
      pinned: true,
      backgroundColor: const Color(0xFF1B5E20),  
      leading: null,  
      actions: [
        IconButton(
          icon: const Icon(Icons.edit, color: Colors.white),
          onPressed: () {
            
          },
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF66BB6A),  
                Color(0xFF388E3C),  
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SafeArea(
            child: Center(
              child: Hero(
                tag: 'profile_image',
                child: Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: GradientBoxBorder(
                      gradient: LinearGradient(
                        colors: [
                          Colors.green.shade300,
                          Colors.green.shade700,
                        ],
                      ),
                      width: 5,
                    ),
                    image: profileImageUrl != null
                      ? DecorationImage(
                          image: CachedNetworkImageProvider(profileImageUrl!),
                          fit: BoxFit.cover,
                        )
                      : null,
                  ),
                  child: profileImageUrl == null
                    ? const Icon(
                        Icons.person,
                        size: 100,
                        color: Colors.white54,
                      )
                    : null,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Column(
      children: [
        Text(
          userName,
          style: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          email,
          style: TextStyle(
            fontSize: 16,
            color: Colors.green.shade200,  
          ),
        ),
      ],
    );
  }

  Widget _buildStatsRow() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        color: const Color(0xFF388E3C),  
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildStatColumn('Recycling Centers', '120'),
          _buildStatColumn('Total E-Waste Collected (kg)', '8500'),
          _buildStatColumn('Users Contributed', '2.5K'),
        ],
      ),
    );
  }

  Widget _buildStatColumn(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.green.shade100,  
          ),
        ),
      ],
    );
  }

  Widget _buildProfileActions(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          _buildActionTile(
            icon: Icons.person_outline,
            title: 'Edit Profile',
            subtitle: 'Update your personal information',
            onTap: () {
              
            },
          ),
          const SizedBox(height: 15),
          _buildActionTile(
            icon: Icons.settings_outlined,
            title: 'Settings',
            subtitle: 'Manage app preferences',
            onTap: () {
              
            },
          ),
          const SizedBox(height: 15),
          _buildActionTile(
            icon: Icons.help_outline,
            title: 'Support',
            subtitle: 'Contact our support team',
            onTap: () {
              
            },
          ),
          const SizedBox(height: 15),
          _buildActionTile(
            icon: Icons.logout,
            title: 'Sign Out',
            subtitle: 'Securely log out of your account',
            onTap: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const SignUpPage()),
              );
            },
            isDestructive: true,
          ),
        ],
      ),
    );
  }

  Widget _buildActionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isDestructive
            ? [Colors.red.shade400, Colors.red.shade600]
            : [
                const Color(0xFF66BB6A),  
                const Color(0xFF388E3C),  
              ],
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Icon(
          icon, 
          color: isDestructive ? Colors.white : Colors.green.shade200,
          size: 30,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isDestructive ? Colors.white : Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(
            color: isDestructive ? Colors.white70 : Colors.green.shade100,
            fontSize: 14,
          ),
        ),
        trailing: Icon(
          Icons.chevron_right,
          color: isDestructive ? Colors.white : Colors.green.shade100,
        ),
      ),
    );
  }
}
