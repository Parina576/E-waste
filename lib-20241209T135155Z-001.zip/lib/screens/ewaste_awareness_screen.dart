import 'package:flutter/material.dart';
import 'sign_up_page.dart';

class EWasteAwarenessScreen extends StatefulWidget {
  const EWasteAwarenessScreen({super.key});

  @override
  _EWasteAwarenessScreenState createState() => _EWasteAwarenessScreenState();
}

class _EWasteAwarenessScreenState extends State<EWasteAwarenessScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<Map<String, dynamic>> _content = [
    {
      'title': 'What is E-Waste?',
      'content': 'E-waste refers to discarded electronic appliances such as mobile phones, computers, and televisions. It is a growing environmental concern due to the toxic materials they contain.',
      'icon': Icons.devices_other_rounded,
    },
    {
      'title': 'Why is E-Waste a Problem?',
      'content': 'Improper disposal of e-waste can lead to harmful chemicals leaching into the soil and water, posing health risks to humans and wildlife. Recycling e-waste properly helps recover valuable materials and reduces environmental impact.',
      'icon': Icons.warning_rounded,
    },
    {
      'title': 'How Can You Help?',
      'content': '1. Recycle your old electronics at certified e-waste recycling centers.\n2. Donate functioning electronics to those in need.\n3. Support companies that prioritize sustainable practices.',
      'icon': Icons.handyman_rounded,
    },
  ];

  void _nextPage() {
    if (_currentPage < _content.length - 1) {
      _pageController.animateToPage(
        _currentPage + 1,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutQuart,
      );
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      _pageController.animateToPage(
        _currentPage - 1,
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOutQuart,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.green.shade600,
              Colors.green.shade900,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Row(
                  children: List.generate(
                    _content.length,
                    (index) => Expanded(
                      child: Container(
                        height: 4,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: index <= _currentPage 
                              ? Colors.white 
                              : Colors.white.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: _content.length,
                  onPageChanged: (index) {
                    setState(() {
                      _currentPage = index;
                    });
                  },
                  itemBuilder: (context, index) {
                    final page = _content[index];
                    return Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Icon
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            padding: const EdgeInsets.all(24),
                            child: Icon(
                              page['icon'],
                              size: 80,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 32),

                          
                          Text(
                            page['title'],
                            style: const TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: -0.5,
                              fontFamily: 'Roboto', 
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 24),

                          
                          Text(
                            page['content'],
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w400,
                              color: Colors.white,
                              height: 1.6,
                              fontFamily: 'Roboto', 
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: _currentPage == 0
                      ? MainAxisAlignment.end
                      : MainAxisAlignment.spaceBetween,
                  children: [
                    if (_currentPage > 0)
                      _buildNavigationButton(
                        icon: Icons.arrow_back_ios_new_rounded,
                        onPressed: _previousPage,
                      ),
                    if (_currentPage < _content.length - 1)
                      _buildNavigationButton(
                        icon: Icons.arrow_forward_ios_rounded,
                        onPressed: _nextPage,
                      ),
                    if (_currentPage == _content.length - 1)
                      _buildProceedButton(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavigationButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        shape: BoxShape.circle,
      ),
      child: IconButton(
        icon: Icon(icon, color: Colors.white),
        iconSize: 32,
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildProceedButton() {
    return ElevatedButton(
      onPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const SignUpPage()),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: Colors.green.shade900,
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        elevation: 6,
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Get Started',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              fontFamily: 'Roboto', 
            ),
          ),
          SizedBox(width: 12),
          Icon(Icons.arrow_forward_rounded),
        ],
      ),
    );
  }
}